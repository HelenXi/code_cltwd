function [data] = generate_uniform_cube(d,n)

data = zeros(d,n);
for j = 1:n
    data(:,j) = rand(d,1)*2-1;
end

end