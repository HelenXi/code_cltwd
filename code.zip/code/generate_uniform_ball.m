function [data] = generate_uniform_ball(d,n,R)
    data = zeros(d,n);
    for j = 1:n
        temp = normrnd(0,1,d);
        temp = temp/norm(temp);
        r = (rand()*R)^(1/d);
        data(:,j) = temp*r;
    end
end