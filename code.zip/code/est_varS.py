#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  7 11:35:56 2022

@author: xijiaqi
"""

import numpy as np

def generate_uniform_sphere(d,n,R):
    data = np.zeros((n,d))
    for j in range(n):
        temp = np.random.normal(0,1,size=(1,d))
        data[j] = R*temp/np.linalg.norm(temp)
    return data

n = 300
ex = 0

'''for i in range(n):
    u = generate_uniform_sphere(3,1,1)
    u = u[0]
    for j in range(n):      
        v = generate_uniform_sphere(3,1,1)
        v = v[0]
        ep = generate_uniform_sphere(3,500,1)
        eq = generate_uniform_sphere(3,500,1)+1
        #ex += 4*sum([np.dot(ep[j],u)**2*np.dot(ep[j],v)**2 + np.dot(eq[j],u)**2*np.dot(eq[j],v)**2 for j in range(500)])/500
        
        ex += sum([(np.dot(ep[j],u)**2+2*np.dot(ep[j],u))*(np.dot(ep[j],v)**2+2*np.dot(ep[j],v)) \
                      + (np.dot(eq[j],u)**2-2*np.dot(eq[j],u))*(np.dot(eq[j],v)**2-2*np.dot(eq[j],v)) for j in range(500)])/500

for i in range(n):
    u = generate_uniform_sphere(3,1,1)
    u = u[0]
    eq = generate_uniform_sphere(3,500,1)+1
    ex += n*sum([np.linalg.norm(eq[j])**4/9-2/3*(np.dot(eq[j],u)**2-2*np.dot(eq[j],u))*np.linalg.norm(ep[j])**2 for j in range(500)])/500

ex = ex/n**2 - 26/9 #4/3 ''' 
        
for i in range(n):
    u = generate_uniform_sphere(3,1,1)
    u = u[0]
    for j in range(n):      
        v = generate_uniform_sphere(3,1,1)
        v = v[0]
        ep = generate_uniform_sphere(3,500,1)
        eq = generate_uniform_sphere(3,500,2)
        ex += sum([np.dot(ep[j],u)**2*np.dot(ep[j],v)**2 + np.dot(eq[j],u)**2*np.dot(eq[j],v)**2/4 for j in range(500)])/500
        

ex = ex/n**2 -5/9   