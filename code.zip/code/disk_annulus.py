#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar  9 20:19:55 2022

@author: xijiaqi
"""
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm

import scipy.stats as stats

from PRW import ProjectionRobustWasserstein
from Optimization.riemann_adap import RiemmanAdaptive


def disk_annulus(n,d,dim=1):

    a = (1./n) * np.ones(n)
    b = (1./n) * np.ones(n)

    # First measure : marginal uniform on the interval [-1,1] 
    X = np.random.uniform(-1,1,size=n)
    X = np.append(X, np.random.uniform(-1,1,size=(n,d-dim)), axis=1)

    # Second measure : marginal uniform on the interval [-1,1] and [-3,-2]U[2,3]
    Y = np.random.choice([1,-1],size = n)*(2 + np.random.uniform(0,1,size=n))
    Y = np.append(X, np.random.uniform(-1,1,size=(n,d-dim)), axis=1)
    
    return a,b,X,Y