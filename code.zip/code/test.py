#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Mar  5 13:29:19 2022

@author: xijiaqi
"""

import ot
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde

sigma = 5
rwpp = (sigma-1)**2/3
rvar = 4*(1-sigma)**2*(sigma**2+1)/45

xs = np.linspace(-20,20,400)
limSdens = np.exp(-xs**2/(2*rvar))/np.sqrt(2*rvar*np.pi)

sample_sizes = [100]

for n in sample_sizes:    
    a, b = np.ones((n,)) / n, np.ones((n,)) / n
    swd = np.empty((2000,))
    for i in range(2000):
        datap = np.random.uniform(-sigma,sigma,size=(n,))
        dataq = np.random.uniform(-1,1,size=(n,))
        swd[i] = ot.wasserstein_1d(datap, dataq, a, b,p=2)
    swd_mean = np.mean(swd)
    swd_std = np.std(swd)
    swd = np.sqrt(n)*(swd - rwpp)
    density = gaussian_kde(swd,'silverman')
    plt.plot(xs,density(xs),color='cadetblue')
    plt.fill_between(xs, density(xs),color='paleturquoise',alpha=0.5)
    plt.plot(xs,limSdens,'palevioletred')
    plt.fill_between(xs,limSdens,color='pink',alpha=0.5)
    plt.xlabel("x")
    plt.ylabel("Density")
    plt.title('sample size n = '+str(n))