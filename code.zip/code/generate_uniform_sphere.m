function [data] = generate_uniform_sphere(d,n)

data = zeros(d,n);
for j = 1:n
    temp = normrnd(0,1,d);
    temp = temp/norm(temp);
    data(:,j) = temp;
end

end